<p align="center"><a href="http://objectmodel.js.org" target="_blank"><img width="400" src="http://objectmodel.js.org/site/res/logo.png"></a></p>

<p align="center">Runtime Type Checking and Data Model Definition for JavaScript</p>

---

## Installation

```bash
$ npm install objectmodel
```

##Documentation, examples, questions

Please refer to the project website: [objectmodel.js.org] [1]

##Fork, build, test

Automatic minifying/concatenating/testing process is done by [Grunt]
```
npm install
grunt
```

Bug reports and pull requests are welcome

[1]:http://objectmodel.js.org
[Grunt]:http://gruntjs.com/getting-started
