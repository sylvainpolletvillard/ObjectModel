var Model = require('../../dist/object-model.umd');
testSuite(Model);