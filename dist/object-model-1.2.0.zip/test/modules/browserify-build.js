(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
(function (globals, factory) {
 if (typeof define === 'function' && define.amd) define(factory); // AMD
 else if (typeof exports === 'object') module.exports = factory(); // Node
 else globals['Model'] = factory(); // globals
}(this, function () {
// shim for Function.name for browsers that don't support it. IE, I'm looking at you.
if (!("name" in Function.prototype && "name" in (function x() {}))) {
	Object.defineProperty(Function.prototype, "name", {
		get: function() {
			var results = Function.prototype.toString.call(this).match(/\s*function\s+([^\(\s]*)\s*/);
			return results && results[1];
		}
	});
}

function isFunction(o){
	return typeof o === "function";
}
function isObject(o){
    return typeof o === "object";
}
function isPlainObject(o){
	return o && isObject(o) && Object.getPrototypeOf(o) === Object.prototype;
}

var isArray = function(a){ return a instanceof Array; };

function toString(obj, stack){
	if(stack && (stack.length > 15 || stack.indexOf(obj) >= 0)){ return '...'; }
	if(obj == null){ return String(obj); }
	if(typeof obj == "string"){ return '"'+obj+'"'; }
	stack = [obj].concat(stack);
	if(isFunction(obj)){ return obj.name || obj.toString(stack); }
	if(isArray(obj)){
		return '[' + obj.map(function(item) {
				return toString(item, stack);
			}).join(', ') + ']';
	}
	if(obj && isObject(obj)){
		var indent = (new Array(stack.length-1)).join('\t');
		return '{' + Object.keys(obj).map(function(key){
				return '\n' + indent + key + ': ' + toString(obj[key], stack);
			}).join(',') + '\n' + '}';
	}
	return String(obj)
}

function bettertypeof(obj){
	return ({}).toString.call(obj).match(/\s([a-zA-Z]+)/)[1];
}

function cloneArray(arr){
	return Array.prototype.slice.call(arr);
}

function merge(target, src, deep) {
	Object.keys(src || {}).forEach(function(key){
		if(deep && isPlainObject(src[key])){
			var o = {};
			merge(o, target[key], deep);
			merge(o, src[key], deep);
			target[key] = o;
		} else {
			target[key] = src[key]
		}
	});
}

function define(obj, key, val, enumerable) {
	Object.defineProperty(obj, key, {
		value: val,
		enumerable: !!enumerable,
		writable: true,
		configurable: true
	});
}

var canSetProto = !!Object.setPrototypeOf || {__proto__:[]} instanceof Array;
Object.setPrototypeOf = Object.setPrototypeOf || (canSetProto
    ? function(o, p){ o.__proto__ = p; }
    : function(o, p){ for(var k in p){ o[k] = p[k]; } ensureProto(o, p); });

Object.getPrototypeOf = Object.getPrototypeOf && canSetProto ? Object.getPrototypeOf : function(o){
    return o.__proto__ || (o.constructor ? o.constructor.prototype : null);
};

function ensureProto(o, p){
	if(!canSetProto){
		define(o, "__proto__", p);
	}
}

function setProto(constructor, proto, protoConstructor){
	constructor.prototype = Object.create(proto);
	constructor.prototype.constructor = protoConstructor || constructor;
	ensureProto(constructor.prototype, proto);
}

function setConstructor(model, constructor){
	Object.setPrototypeOf(model, constructor.prototype);
	define(model, "constructor", constructor);
}

var isProxySupported = isFunction(this.Proxy);
function Model(def){
	if(!isLeaf(def)) return Model.Object(def);

	var model = function(obj) {
		model.validate(obj);
		return obj;
	};

	setConstructor(model, Model);
	model.definition = def;
	model.assertions = [];
	model.errorStack = [];
	return model;
}

setProto(Model, Function.prototype);

Model.prototype.toString = function(stack){
	return parseDefinition(this.definition).map(function(d){
		return toString(d, stack);
	}).join(" or ");
};

Model.prototype.validate = function(obj, errorCollector){
	this.validator(obj, null, [], this.errorStack);
	this.unstack(errorCollector);
};

Model.prototype.test = function(obj){
	var errorStack = [];
	this.validator(obj, null, [], errorStack);
	return !errorStack.length;
};

Model.prototype.extend = function(){
	var def, proto,
		assertions = cloneArray(this.assertions),
		args = cloneArray(arguments);

	if(Model.instanceOf(this, Model.Object)){
		def = {};
		proto = {};
		merge(def, this.definition);
		merge(proto, this.prototype);
		args.forEach(function(arg){
			if(Model.instanceOf(arg, Model)){
				merge(def, arg.definition, true);
				merge(proto, arg.prototype, true);
			} else {
				merge(def, arg, true);
			}
		})
	} else {
		def = args.reduce(function(def, ext){
			return def.concat(parseDefinition(ext));
		}, parseDefinition(this.definition))
		.filter(function(value, index, self) {
			return self.indexOf(value) === index; // remove duplicates
		});
	}

	args.forEach(function(arg){
		if(Model.instanceOf(arg, Model)){
			assertions = assertions.concat(arg.assertions);
		}
	});

	var submodel = new this.constructor(def);
	setProto(submodel, this.prototype);
	merge(submodel.prototype, proto);
	submodel.assertions = assertions;
	return submodel;
};

Model.prototype.assert = function(assertion, message){
	define(assertion, "description", message);
	this.assertions.push(assertion);
	return this;
};

Model.prototype.errorCollector = function(errors){
	throw new TypeError(errors.map(function(e){ return e.message; }).join('\n'));
};

Model.instanceOf = function(obj, Constructor){ // instanceof sham for IE<9
	return canSetProto ? obj instanceof Constructor	: (function recursive(o, stack){
		if(o == null || stack.indexOf(o) !== -1) return false;
		var proto = Object.getPrototypeOf(o);
		stack.push(o);
		return proto === Constructor.prototype || recursive(proto, stack);
	})(obj, [])
};

Model.conventionForConstant = function(key){ return key.toUpperCase() === key };
Model.conventionForPrivate = function(key){ return key[0] === "_" };

// private methods
Model.prototype.validator = function(obj, path, callStack, errorStack){
	checkDefinition(obj, this.definition, path, callStack, errorStack);
	matchAssertions(obj, this.assertions, errorStack);
};

// throw all errors collected
Model.prototype.unstack = function(errorCollector){
	if(!this.errorStack.length){
		return;
	}
	if(!errorCollector){
		errorCollector = this.errorCollector;
	}
	var errors = this.errorStack.map(function(err){
		if(!err.message){
			var expected = isArray(err.expected) ? err.expected : [err.expected];
			err.message = ("expecting " + (err.path ? err.path + " to be " : "")
			+ expected.map(function(d){ return toString(d); }).join(" or ")
			+ ", got " + (err.received != null ? bettertypeof(err.received) + " " : "")
			+ toString(err.received))
		}
		return err;
	});
	this.errorStack = [];
	errorCollector.call(this, errors);
};

function isLeaf(def){
	return bettertypeof(def) != "Object";
}

function parseDefinition(def){
	if(isLeaf(def)){
		if(!isArray(def)) return [def];
		else if(def.length === 1) return def.concat(undefined, null);
	} else {
		Object.keys(def).forEach(function(key) {
			def[key] = parseDefinition(def[key]);
		});
	}
	return def;
}

function checkDefinition(obj, def, path, callStack, errorStack){
	var err;
	if(Model.instanceOf(def, Model)){
		var indexFound = callStack.indexOf(def);
		if(indexFound !== -1 && callStack.slice(indexFound+1).indexOf(def) !== -1){
			return; //if found twice in call stack, cycle detected, skip validation
		}
		return def.validator(obj, path, callStack.concat(def), errorStack);
	} else if(isLeaf(def)){
		var pdef = parseDefinition(def);
		for(var i= 0, l=pdef.length; i<l; i++){
			if(checkDefinitionPart(obj, pdef[i], path, callStack)){
				return;
			}
		}
		errorStack.push({
			expected: def,
			received: obj,
			path: path
		});
	} else {
		Object.keys(def).forEach(function(key) {
			var val = obj != null ? obj[key] : undefined;
			checkDefinition(val, def[key], path ? path + '.' + key : key, callStack, errorStack);
		});
	}
}

function checkDefinitionPart(obj, def, path, callStack){
	if(obj == null){
		return obj === def;
	}
	if(!isLeaf(def)|| Model.instanceOf(def, Model)){
		var errorStack=[];
		checkDefinition(obj, def, path, callStack, errorStack);
		return !errorStack.length;
	}
	if(def instanceof RegExp){
		return def.test(obj);
	}

	return obj === def
		|| (isFunction(def) && obj instanceof def)
		|| obj.constructor === def;
}

function matchAssertions(obj, assertions, errorStack){
	for(var i=0, l=assertions.length; i<l ; i++ ){
		if(!assertions[i](obj)){
			errorStack.push({
				message: "assertion failed: "+ (assertions[i].description || toString(assertions[i]))
			});
		}
	}
}
Model.Object = function ObjectModel(def){

	var model = function(obj) {
		if(!(this instanceof model)){
			return new model(obj);
		}
		merge(this, obj, true);
		var proxy = getProxy(model, this, model.definition);
		ensureProto(proxy, model.prototype);
		model.validate(proxy);
		return proxy;
	};

	setConstructor(model, Model.Object);
	model.definition = def;
	model.assertions = [];
	model.errorStack = [];
	return model;
};

setProto(Model.Object, Model.prototype, Model);

Model.Object.prototype.defaults = function(p){
	merge(this.prototype, p);
	return this;
};

Model.Object.prototype.toString = function(stack){
	return toString(this.definition, stack);
};

Model.Object.prototype.validator = function(obj, path, callStack, errorStack){
	if(!isObject(obj)){
		errorStack.push({
			expected: this,
			received: obj,
			path: path
		});
	} else {
		checkDefinition(obj, this.definition, path, callStack, errorStack);
	}
	matchAssertions(obj, this.assertions, this.errorStack);
};

function getProxy(model, obj, defNode, path) {
	if(Model.instanceOf(defNode, Model) && obj && !Model.instanceOf(obj, defNode)) {
		return defNode(obj);
	} else if(isLeaf(defNode)){
		return obj;
	}
	else {
		var wrapper = obj instanceof Object ? obj : {};
		var proxy = Object.create(Object.getPrototypeOf(wrapper));

		for(var key in wrapper){
			if(wrapper.hasOwnProperty(key) && !(key in defNode)){
				proxy[key] = wrapper[key]; // properties out of model definition are kept
			}
		}

		Object.keys(defNode).forEach(function(key) {
			var newPath = (path ? path + '.' + key : key);
			var isConstant = Model.conventionForConstant(key);
			Object.defineProperty(proxy, key, {
				get: function () {
					return getProxy(model, wrapper[key], defNode[key], newPath);
				},
				set: function (val) {
					if(isConstant && wrapper[key] !== undefined){
						model.errorStack.push({ message: "cannot redefine constant " + key });
					}
					var newProxy = getProxy(model, val, defNode[key], newPath);
					checkDefinition(newProxy, defNode[key], newPath, [], model.errorStack);
					var oldValue = wrapper[key];
					wrapper[key] = newProxy;
					matchAssertions(obj, model.assertions, model.errorStack);
					if(model.errorStack.length){
						wrapper[key] = oldValue;
						model.unstack();
					}
				},
				enumerable: !Model.conventionForPrivate(key)
			});
		});
		return proxy;
	}
}
var ARRAY_MUTATOR_METHODS = ["pop", "push", "reverse", "shift", "sort", "splice", "unshift"];

Model.Array = function ArrayModel(def){

	var model = function(array) {

		var proxy;
		model.validate(array);
		if(isProxySupported){
			proxy = new Proxy(array, {
				get: function (arr, key) {
					return (ARRAY_MUTATOR_METHODS.indexOf(key) >= 0 ? proxifyArrayMethod(arr, key, model) : arr[key]);
				},
				set: function (arr, key, val) {
					setArrayKey(arr, key, val, model);
				}
			});
		} else {
			proxy = Object.create(Array.prototype);
			for(var key in array){
				if(array.hasOwnProperty(key)){
					proxifyArrayKey(proxy, array, key, model);
				}
			}
			Object.defineProperty(proxy, "length", { get: function() { return array.length; } });
			ARRAY_MUTATOR_METHODS.forEach(function (method) {
				define(proxy, method, proxifyArrayMethod(array, method, model, proxy));
			});
		}

		setConstructor(proxy, model);
		return proxy;
	};

	setProto(model, Array.prototype);
	setConstructor(model, Model.Array);
	model.definition = def;
	model.assertions = [];
	model.errorStack = [];
	return model;
};

setProto(Model.Array, Model.prototype, Model);

Model.Array.prototype.toString = function(stack){
	return 'Array of ' + toString(this.definition, stack);
};

Model.Array.prototype.validator = function(arr, path, callStack, errorStack){
	if(!isArray(arr)){
		errorStack.push({ expected: this, received: arr });
	} else {
		for(var i=0, l=arr.length; i<l; i++){
			checkDefinition(arr[i], this.definition, (path||'Array')+'['+i+']', callStack, errorStack);
		}
	}
	matchAssertions(arr, this.assertions, errorStack);
};

function proxifyArrayKey(proxy, array, key, model){
	Object.defineProperty(proxy, key, {
		enumerable: true,
		get: function () {
			return array[key];
		},
		set: function (val) {
			setArrayKey(array, key, val, model);
		}
	});
}

function proxifyArrayMethod(array, method, model, proxy){
	return function() {
		var testArray = array.slice();
		Array.prototype[method].apply(testArray, arguments);
		model.validate(testArray);
		if(!isProxySupported){
			for(var key in testArray){
				if(testArray.hasOwnProperty(key) && !(key in proxy)){
					proxifyArrayKey(proxy, array, key, model);
				}
			}
		}
		return Array.prototype[method].apply(array, arguments);
	};
}

function setArrayKey(array, key, value, model){
	if(parseInt(key) === +key && key >= 0){
		checkDefinition(value, model.definition, 'Array['+key+']', [], model.errorStack);
	}
	var testArray = array.slice();
	testArray[key] = value;
	matchAssertions(testArray, model.assertions, model.errorStack);
	model.unstack();
	array[key] = value;
}
Model.Function = function FunctionModel(){

	var model = function(fn) {

		var def = model.definition;
		var proxyFn = function () {
			var args = [];
			merge(args, def.defaults);
			merge(args, cloneArray(arguments));
			if (args.length > def.arguments.length) {
				model.errorStack.push({
					expected: toString(fn) + " to be called with " + def.arguments.length + " arguments",
					received: args.length
				});
			}
			def.arguments.forEach(function (argDef, i) {
				checkDefinition(args[i], argDef, 'arguments[' + i + ']', [], model.errorStack);
			});
			matchAssertions(args, model.assertions, model.errorStack);
			var returnValue = fn.apply(this, args);
			if ("return" in def) {
				checkDefinition(returnValue, def.return, 'return value', [], model.errorStack);
			}
			model.unstack();
			return returnValue;
		};
		setConstructor(proxyFn, model);
		return proxyFn;
	};

	setProto(model, Function.prototype);
	setConstructor(model, Model.Function);
	model.definition = { arguments: cloneArray(arguments) };
	model.assertions = [];
	model.errorStack = [];
	return model;
};

setProto(Model.Function, Model.prototype, Model);

Model.Function.prototype.toString = function(stack){
	var out = 'Model.Function('+this.definition.arguments.map(function(argDef){
			return toString(argDef, stack);
		}).join(",") +')';
	if("return" in this.definition) {
		out += ".return(" + toString(this.definition.return) + ")";
	}
	return out;
};

Model.Function.prototype.return = function(def){
	this.definition.return = def;
	return this;
};

Model.Function.prototype.defaults = function(){
	this.definition.defaults = cloneArray(arguments);
	return this;
};

Model.Function.prototype.validator = function(f, path, callStack, errorStack){
	if(!isFunction(f)){
		errorStack.push({ expected: "Function", received: f });
	}
};
return Model;
}));
},{}],2:[function(require,module,exports){
var Model = require('../../dist/object-model.umd');
testSuite(Model);
},{"../../dist/object-model.umd":1}]},{},[2]);
