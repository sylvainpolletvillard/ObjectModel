var NumberModelAccessors = {
	"Integer": function(val){ return Number.isInteger(val); },
	"Positive": function(val){ return val >= 0; },
	"Negative": function(val){ return val <= 0; }
};

function setAccessors(model){
	for(var accessorName in NumberModelAccessors){
		Object.defineProperty(model, accessorName, {
			get: function(){
				return setAccessors(model.extend().assert(NumberModelAccessors[accessorName]));
			}
		});
	}
	return model;
}

Model.Number = setAccessors(Model(Number));